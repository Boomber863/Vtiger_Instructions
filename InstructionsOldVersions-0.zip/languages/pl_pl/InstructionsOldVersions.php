<?php
$languageStrings = array(
    'InstructionsOldVersions' => 'Instrukcje - poprzednie wersje',
    'SINGLE_InstructionsOldVersions' => 'Poprzednia wersja instrukcji',
    'LBL_INSTRUCTIONSOLDVERSIONS_INFORMATION' => 'Informacje o poprzednich wersjach instrukcji',
    'LBL_CUSTOM_INFORMATION' => 'Informacje dodatkowe',
    'LBL_DESCRIPTION_INFORMATION' => 'Opis szczegółowy',
    'LBL_DESCRIPTION' => 'Opis',
    'LBL_NAME' => 'Nazwa',
    'LBL_ASSIGNED_TO' => 'Przypisane do',
    'LBL_INSTRUCTION' => 'Instrukcja',
    'Instruction Name' => 'Nazwa Instrukcji',
    'Contents of Instruction' => 'Treść Instrukcji',
    'Instructions - previous versions' => 'Instrukcje - poprzednie wersje',
    'Original Instruction' => 'Oryginalna Instrukcja',
    'Modified By' => 'Ostatnio modyfikowane przez',
    'Restore this copy' => 'Przywróć kopię',
);

$jsLanguageStrings = array(
	'JS_CONFIRM_RESTORE_MESSAGE' => 'Czy na pewno chcesz przywrócić tę kopię?',
);