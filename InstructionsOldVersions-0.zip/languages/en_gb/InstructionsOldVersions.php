<?php
$languageStrings = array(
    'InstructionsOldVersions' => 'Instructions - previous versions',
    'SINGLE_InstructionsOldVersions' => 'Previous Version of Instruction',
    'LBL_INSTRUCTIONSOLDVERSIONS_INFORMATION' => 'Information about Previous Versions of Instructions',
    'LBL_CUSTOM_INFORMATION' => 'Custom Information',
    'LBL_DESCRIPTION_INFORMATION' => 'Detailed Description',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Name',
    'LBL_ASSIGNED_TO' => 'Assigned To',
    'LBL_INSTRUCTION' => 'Instruction',
    'Instruction Name' => 'Instruction Name',
    'Contents of Instruction' => 'Contents of Instruction',
    'Instructions - previous versions' => 'Instructions - previous versions',
    'Original Instruction' => 'Original Instruction',
    'Modified By' => 'Last Modified By',
    'Restore this copy' => 'Restore this copy',
);

$jsLanguageStrings = array(
	'JS_CONFIRM_RESTORE_MESSAGE' => 'Are you sure you want to restore this copy?',
);