<script>
    var InstructionsOldVersions_DetailView_Model = {
        confirmRestore: function(recordId) {
            var confirmMessage = app.vtranslate('JS_CONFIRM_RESTORE_MESSAGE');
            if (confirm(confirmMessage)) {
                window.location.href = 'index.php?module=InstructionsOldVersions&action=Restore&record=' + recordId;
            }
        }
    };
</script>
<?php
class InstructionsOldVersions_DetailView_Model extends Vtiger_DetailView_Model {
        /**
	 * Function to get the detail view links (links and widgets)
	 * @param <array> $linkParams - parameters which will be used to calicaulate the params
	 * @return <array> - array of link models in the format as below
	 *                   array('linktype'=>list of link models);
	 */
	public function getDetailViewLinks($linkParams) {
                $recordId = $linkParams['RECORD'];

                $restoreUrl = "index.php?module=InstructionsOldVersions&action=Restore&record={$recordId}";

                $restoreButton = [
                'linktype' => 'DETAILVIEWBASIC',
                'linklabel' => 'Restore this copy',
                'linkurl' => 'javascript:InstructionsOldVersions_DetailView_Model.confirmRestore(' . $recordId . ')',
                'linkicon' => '',
                ];

                $detailViewLinks = parent::getDetailViewLinks($linkParams);

                $detailViewLinks['DETAILVIEWBASIC'][] = Vtiger_Link_Model::getInstanceFromValues($restoreButton);

                return $detailViewLinks;
	}

}
?>