<?php
include_once 'modules/Vtiger/CRMEntity.php';

class InstructionsOldVersions_Restore_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        $recordId = $request->get('record');
        if (!empty($recordId)) {
            $recordModel = Vtiger_Record_Model::getInstanceById($recordId, 'InstructionsOldVersions');
            $name = $recordModel->get('instructionname');
            $instruction = $recordModel->get('cf_869');
            $assignedTo = $recordModel->get('assigned_user_id');

            $originalInstructionId = $recordModel->get('originalinstruction');

            $originalRecordModel = Vtiger_Record_Model::getInstanceById($originalInstructionId, 'Instructions');

            if ($originalRecordModel) {
                $copy_name = $originalRecordModel->get('instructionname');
                $copy_instruction = $originalRecordModel->get('cf_865');
                $copy_assignedTo = $originalRecordModel->get('assigned_user_id');
        
                $copyRecordModel = Vtiger_Record_Model::getCleanInstance('InstructionsOldVersions');
        
                $copyRecordModel->set('instructionname', $copy_name);
                $copyRecordModel->set('cf_869', $copy_instruction);
                $copyRecordModel->set('assigned_user_id', $copy_assignedTo);
                $copyRecordModel->set('originalinstruction', $originalRecordModel->getId());
        
                $copyRecordModel->save();
        
                $relationModel = Vtiger_Relation_Model::getInstance(Vtiger_Module_Model::getInstance('Instructions'), Vtiger_Module_Model::getInstance('InstructionsOldVersions'));
                $relationModel->addRelation($originalRecordModel->getId(), $copyRecordModel->getId());


                $originalRecordModel->set('id', $originalInstructionId);
			    $originalRecordModel->set('mode', 'edit');
                $originalRecordModel->set('instructionname', $name);
                $originalRecordModel->set('cf_865', $instruction);
                $originalRecordModel->set('assigned_user_id', $assignedTo);

                $originalRecordModel->save();

                header("Location: index.php?module=Instructions&view=Detail&record={$originalInstructionId}");
            } else {
                echo 'Błąd: Nie można znaleźć rekordu w module "Instructions".';
            }
        }
    }
}
?>
