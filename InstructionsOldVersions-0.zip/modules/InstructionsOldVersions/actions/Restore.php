<?php
include_once 'modules/Vtiger/CRMEntity.php';

class InstructionsOldVersions_Restore_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        $recordId = $request->get('record');
        if (!empty($recordId)) {
            $recordModel = Vtiger_Record_Model::getInstanceById($recordId, 'InstructionsOldVersions');
            $name = $recordModel->get('instructionname');
            $instruction = $recordModel->get('cf_869');
            $assignedTo = $recordModel->get('assigned_user_id');

            $originalInstructionId = $recordModel->get('originalinstruction');

            $originalRecordModel = Vtiger_Record_Model::getInstanceById($originalInstructionId, 'Instructions');

            if ($originalRecordModel) {
                $originalRecordModel->set('id', $originalInstructionId);
			    $originalRecordModel->set('mode', 'edit');
                $originalRecordModel->set('instructionname', $name);
                $originalRecordModel->set('cf_865', $instruction);
                $originalRecordModel->set('assigned_user_id', $assignedTo);

                $originalRecordModel->save();

                header("Location: index.php?module=Instructions&view=Detail&record={$originalInstructionId}");
            } else {
                echo 'Błąd: Nie można znaleźć rekordu w module "Instructions".';
            }
        }
    }
}
?>
