<?php
$languageStrings = array(
    'Instructions_old_versions' => 'Instructions - previous versions',
    'SINGLE_Instructions_old_versions' => 'Previous Version of Instruction',
    'LBL_INSTRUCTIONS_OLD_VERSIONS_INFORMATION' => 'Information about Previous Versions of Instructions',
    'LBL_CUSTOM_INFORMATION' => 'Custom Information',
    'LBL_DESCRIPTION_INFORMATION' => 'Detailed Description',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Name',
    'LBL_ASSIGNED_TO' => 'Assigned To',
    'LBL_INSTRUCTION' => 'Instruction',
    'Instruction Name' => 'Instruction Name',
    'Contents of Instruction' => 'Contents of Instruction',
    'Instructions - previous versions' => 'Instructions - previous versions',
    'Original Instruction' => 'Original Instruction',
    'Modified By' => 'Last Modified By',
);