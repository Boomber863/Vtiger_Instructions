<?php
$languageStrings = array(
    'Instructions_old_versions' => 'Poprzednie wersje instrukcji',
    'SINGLE_Instructions_old_versions' => 'Poprzednia wersja instrukcji',
    'LBL_INSTRUCTIONS_OLD_VERSIONS_INFORMATION' => 'Informacje o poprzednich wersjach instrukcji',
    'LBL_CUSTOM_INFORMATION' => 'Informacje dodatkowe',
    'LBL_DESCRIPTION_INFORMATION' => 'Opis szczegółowy',
    'LBL_DESCRIPTION' => 'Opis',
    'LBL_NAME' => 'Nazwa',
    'LBL_ASSIGNED_TO' => 'Przypisane do',
    'LBL_INSTRUCTION' => 'Instrukcja',
);