<?php
$languageStrings = array(
    'Instructions' => 'Instrukcje',
    'SINGLE_Instructions' => 'Instrukcja',
    'LBL_INSTRUCTIONS_INFORMATION' => 'Informacje o instrukcji',
    'LBL_CUSTOM_INFORMATION' => 'Informacje dodatkowe',
    'LBL_DESCRIPTION_INFORMATION' => 'Opis szczegółowy',
    'LBL_DESCRIPTION' => 'Opis',
    'LBL_NAME' => 'Nazwa',
    'LBL_ASSIGNED_TO' => 'Przypisane do',
    'LBL_INSTRUCTION' => 'Instrukcja',
    'Instruction Name' => 'Nazwa Instrukcji',
    'Contents of Instruction' => 'Treść Instrukcji',
    'Instructions - previous versions' => 'Instrukcje - poprzednie wersje',
    'Modified By' => 'Ostatnio modyfikowane przez',
);
