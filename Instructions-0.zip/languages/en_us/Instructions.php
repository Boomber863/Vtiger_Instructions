<?php
$languageStrings = array(
    'Instructions' => 'Instructions',
    'SINGLE_Instructions' => 'Instruction',
    'LBL_INSTRUCTIONS_INFORMATION' => 'Instructions Information',
    'LBL_CUSTOM_INFORMATION' => 'Custom Information',
    'LBL_DESCRIPTION_INFORMATION' => 'Detailed Description',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Name',
    'LBL_ASSIGNED_TO' => 'Assigned To',
    'LBL_INSTRUCTION' => 'Instruction',
    'Instruction Name' => 'Instruction Name',
    'Contents of Instruction' => 'Contents of Instruction',
    'InstructionsOldVersions' => 'Instructions - previous versions',
    'Instructions - previous versions' => 'Instructions - previous versions',
    'Modified By' => 'Last Modified By',
    'Send to Bot' => 'Send to Bot',
);

$jsLanguageStrings = array(
	'JS_SEND_BOT_MESSAGE' => 'Please enter your Telegram chat ID:',
);