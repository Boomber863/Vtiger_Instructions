<?php
$languageStrings = array(
    'Instructions' => 'Instructions',
    'SINGLE_Instructions' => 'Instruction',
    'LBL_INSTRUCTIONS_INFORMATION' => 'Instructions Information',
    'LBL_CUSTOM_INFORMATION' => 'Custom Information',
    'LBL_DESCRIPTION_INFORMATION' => 'Detailed Description',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Name',
    'LBL_ASSIGNED_TO' => 'Assigned To',
    'LBL_INSTRUCTION' => 'Instruction',
);
