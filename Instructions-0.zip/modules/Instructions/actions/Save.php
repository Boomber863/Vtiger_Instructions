<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
include_once 'modules/Vtiger/CRMEntity.php';

class Instructions_Save_Action extends Vtiger_Save_Action {
    public function process(Vtiger_Request $request) {
        $recordId = $request->get('record');
        if (!empty($recordId)) {
            $this->createOldVersionRecord($recordId);
        }
        parent::process($request);
    }

    public function createOldVersionRecord($recordId) {
        $recordModel = Vtiger_Record_Model::getInstanceById($recordId, 'Instructions');
        $name = $recordModel->get('instructionname');
        $instruction = $recordModel->get('cf_865');
        $assignedTo = $recordModel->get('assigned_user_id');

        $newRecordModel = Vtiger_Record_Model::getCleanInstance('InstructionsOldVersions');

        $newRecordModel->set('instructionname', $name);
        $newRecordModel->set('cf_869', $instruction);
        $newRecordModel->set('assigned_user_id', $assignedTo);
        $newRecordModel->set('originalinstruction', $recordModel->getId());

        $newRecordModel->save();

        $relationModel = Vtiger_Relation_Model::getInstance(Vtiger_Module_Model::getInstance('Instructions'), Vtiger_Module_Model::getInstance('InstructionsOldVersions'));
        $relationModel->addRelation($recordModel->getId(), $newRecordModel->getId());
    }
}