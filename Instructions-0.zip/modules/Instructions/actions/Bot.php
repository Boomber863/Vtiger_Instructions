<?php
include_once 'modules/Vtiger/CRMEntity.php';

class Instructions_Bot_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        $recordId = $request->get('record');
        if (!empty($recordId)) {
            $chatId = $request->get('chat_id');

            $recordModel = Vtiger_Record_Model::getInstanceById($recordId, 'Instructions');
            $instruction = $recordModel->get('cf_865');

            $data = array(
                'chat_id' => $chatId,
                'instruction' => $instruction
            );

            $pythonApiUrl = 'http://localhost:81/php_request';
            $options = array(
                'http' => array(
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data),
                ),
            );

            $context = stream_context_create($options);
            $result = file_get_contents($pythonApiUrl, false, $context);
            header("Location: index.php?module=Instructions&view=Detail&record={$recordId}");
        }
    }
}
?>
