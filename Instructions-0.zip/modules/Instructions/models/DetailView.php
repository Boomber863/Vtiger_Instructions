<script>
    var Instructions_DetailView_Model = {
        openChatIdModal: function(recordId) {
            var message = app.vtranslate('JS_SEND_BOT_MESSAGE');
            var chatId = prompt(message);
            if (chatId !== null) {
                window.location.href = 'index.php?module=Instructions&action=Bot&record=' + recordId + '&chat_id=' + chatId;
            }
        }
    };
</script>
<?php
class Instructions_DetailView_Model extends Vtiger_DetailView_Model {
        /**
	 * Function to get the detail view links (links and widgets)
	 * @param <array> $linkParams - parameters which will be used to calicaulate the params
	 * @return <array> - array of link models in the format as below
	 *                   array('linktype'=>list of link models);
	 */
	public function getDetailViewLinks($linkParams) {
                $recordId = $linkParams['RECORD'];

                $botUrl = "index.php?module=Instructions&action=Bot&record={$recordId}";

                $botButton = [
                'linktype' => 'DETAILVIEWBASIC',
                'linklabel' => 'Send to Bot',
                'linkurl' => "javascript:Instructions_DetailView_Model.openChatIdModal($recordId)",
                'linkicon' => '',
                ];

                $detailViewLinks = parent::getDetailViewLinks($linkParams);

                $detailViewLinks['DETAILVIEWBASIC'][] = Vtiger_Link_Model::getInstanceFromValues($botButton);

                return $detailViewLinks;
	}
}
?>